# SmartBandLogger is an extension for Sony SmartBands.

# build instructions
```
./gradlew build
```

# try it

https://play.google.com/store/apps/details?id=cl.felipebarriga.android.smartbandlogger
