package cl.felipebarriga.android.smartbandlogger;

/**
 * Copyright (c) 2015 Felipe Barriga Richards. See Copyright Notice in LICENSE file.
 */
public class Common {
    public enum ContextMenuActions {
        OPEN,
        SHARE,
        DELETE
    }

}
