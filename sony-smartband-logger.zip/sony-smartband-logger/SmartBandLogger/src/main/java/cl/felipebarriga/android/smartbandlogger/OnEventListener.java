package cl.felipebarriga.android.smartbandlogger;

/**
 * Copyright (c) 2015 Felipe Barriga Richards. See Copyright Notice in LICENSE file.
 */
public interface OnEventListener {
    void onEvent(OnEventObject e);
}
